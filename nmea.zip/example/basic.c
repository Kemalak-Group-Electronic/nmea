// To build: gcc examples/minimum.c -lnmea -o minimum

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "nmea0183.h"

nmea_gpgga_s mygpgga;
nmea_gprmc_s mygprmc;

// const char *gpsStream =
//   "$GPRMC,045103.000,A,3014.1984,N,09749.2872,W,0.67,161.46,030913,,,A*7C\r\n"
//   "$GPGGA,045104.000,3014.1985,N,09749.2873,W,1,09,1.2,211.6,M,-22.5,M,,0000*62\r\n"
//   "$GPRMC,045200.000,A,3014.3820,N,09748.9514,W,36.88,65.02,030913,,,A*77\r\n"
//   "$GPGGA,045201.000,3014.3864,N,09748.9411,W,1,10,1.2,200.8,M,-22.5,M,,0000*6C\r\n"
//   "$GPRMC,045251.000,A,3014.4275,N,09749.0626,W,0.51,217.94,030913,,,A*7D\r\n"
//   "$GPGGA,045252.000,3014.4273,N,09749.0628,W,1,09,1.3,206.9,M,-22.5,M,,0000*6F\r\n";

int main(void)
{
	// Sentence string to be parsed
	const char gpgga1[] = "$GPGGA,123519,4042.6142,N,07400.4168,W,1,08,0.9,10.0,M,46.9,M,,*5B\r\n";
	const char gpgga2[] = "$GPGGA,095601,,,,,0,00,99.9,,M,,M,,*48\r\n"; // Invalid/no fix
	const char gpgga3[] = "$GPGGA,141350,5128.6200,N,00027.5800,W,2,10,0.8,50.0,M,45.0,M,2.0,0001*6B\r\n";
	const char gpgga4[] = "$GPGGA,061235,3540.4480,N,13945.1234,E,1,07,1.2,30.0,M,40.0,M,,*6A\r\n";
	const char gpgga5[] = "$GPGGA,083000,2742.3421,N,08519.4567,E,1,09,0.7,1300.0,M,-34.0,M,,*63\r\n";

	const char gprmc1[] = "$GPRMC,123519,A,4042.6142,N,07400.4168,W,000.5,054.7,210725,,,*1C\r\n"; // Valid fix in NY
	const char gprmc2[] = "$GPRMC,095601,V,,,,,,,210725,,,N*4E\r\n";                            // Invalid/no fix
	const char gprmc3[] = "$GPRMC,141350,A,5128.6200,N,00027.5800,W,005.5,089.6,210725,,,*1B\r\n"; // London fix
	const char gprmc4[] = "$GPRMC,061235,A,3540.4480,N,13945.1234,E,003.2,120.5,210725,,,*11\r\n"; // Tokyo moving
	const char gprmc5[] = "$GPRMC,083000,A,2742.3421,N,08519.4567,E,001.2,360.0,210725,,,*1D\r\n"; // Kathmandu fix

	char *sentence = (char *)gpgga1; // Change this to test different sentences
	//parsers_init();
	nmea0183_init(&mygpgga, &mygprmc);
	printf("Parsing NMEA sentence: %s", sentence);

	// Pointer to struct containing the parsed data. Should be freed manually.
	int err;
	

	// // Parse...

	int len = strlen(sentence);
	err = nmea0183_parse(sentence, len, true);
	nmea0183_get_gpgga(&mygpgga);
	if(nmea0183_check_gpgga(&mygpgga) != NMEA_OK) {
	 	printf("Wrong Parser Type \n");
	}

	// printf("Parsing NMEA sentence: %s\n", sentence);
    // //printf("Error Code: %d\n", err);


}